﻿using Exam.DeliveriesManager;
using System.Collections.Generic;
using System.Linq;

namespace Exam.AirlinesManager
{
    public class Program
    {
        static void Main()
        {
        }
    }
}
